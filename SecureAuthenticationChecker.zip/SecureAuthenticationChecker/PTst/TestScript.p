// Model-checking scenarios. Each test asserts both global safety monitors.

test tcValidLogin [main=TestValidLogin]:
    assert AccessControlSafety, LockoutSafety in
    (union AuthenticationSystem, { TestValidLogin });

test tcUnauthenticatedAccess [main=TestUnauthenticatedAccess]:
    assert AccessControlSafety, LockoutSafety in
    (union AuthenticationSystem, { TestUnauthenticatedAccess });

test tcInvalidTOTP [main=TestInvalidTOTP]:
    assert AccessControlSafety, LockoutSafety in
    (union AuthenticationSystem, { TestInvalidTOTP });

test tcAccountLockout [main=TestAccountLockout]:
    assert AccessControlSafety, LockoutSafety in
    (union AuthenticationSystem, { TestAccountLockout });

test tcSessionTermination [main=TestSessionTermination]:
    assert AccessControlSafety, LockoutSafety in
    (union AuthenticationSystem, { TestSessionTermination });
