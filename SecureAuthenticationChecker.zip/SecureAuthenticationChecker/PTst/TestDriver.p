// Each driver creates a fresh authentication server and submits one scenario.

machine TestValidLogin
{
    var auth: AuthenticationServer;

    start state Init
    {
        entry
        {
            auth = new AuthenticationServer();
            send auth, eSubmitValidCredentials;
            send auth, eSubmitValidTOTP;
            send auth, eRequestProtectedResource;
        }
    }
}

machine TestUnauthenticatedAccess
{
    var auth: AuthenticationServer;

    start state Init
    {
        entry
        {
            auth = new AuthenticationServer();
            send auth, eRequestProtectedResource;
        }
    }
}

machine TestInvalidTOTP
{
    var auth: AuthenticationServer;

    start state Init
    {
        entry
        {
            auth = new AuthenticationServer();
            send auth, eSubmitValidCredentials;
            send auth, eSubmitInvalidTOTP;
            send auth, eRequestProtectedResource;
        }
    }
}

machine TestAccountLockout
{
    var auth: AuthenticationServer;

    start state Init
    {
        entry
        {
            auth = new AuthenticationServer();
            send auth, eSubmitInvalidCredentials;
            send auth, eSubmitInvalidCredentials;
            send auth, eSubmitInvalidCredentials;
            send auth, eSubmitValidCredentials;
            send auth, eRequestProtectedResource;
        }
    }
}

machine TestSessionTermination
{
    var auth: AuthenticationServer;

    start state Init
    {
        entry
        {
            auth = new AuthenticationServer();
            send auth, eSubmitValidCredentials;
            send auth, eSubmitValidTOTP;
            send auth, eSessionEnded;
            send auth, eRequestProtectedResource;
        }
    }
}
